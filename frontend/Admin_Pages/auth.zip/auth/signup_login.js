/**
 * Signup_login.js — NexusPay Admin Sign In / Sign Up
 * Handles form switching, password toggle, and login/signup logic.
 */

document.addEventListener('DOMContentLoaded', () => {
  const signinForm   = document.getElementById('signinForm');
  const signupForm   = document.getElementById('signupForm');
  const goToSignup   = document.getElementById('goToSignup');
  const goToSignin   = document.getElementById('goToSignin');
  const toggleSignin = document.getElementById('toggleSigninPass');
  const toggleSignup = document.getElementById('toggleSignupPass');
  const toastWrap    = document.getElementById('toastWrap');

  // ── Form switching ─────────────────────
  goToSignup?.addEventListener('click', e => {
    e.preventDefault();
    signinForm.classList.add('auth-card--hidden');
    signupForm.classList.remove('auth-card--hidden');
  });

  goToSignin?.addEventListener('click', e => {
    e.preventDefault();
    signupForm.classList.add('auth-card--hidden');
    signinForm.classList.remove('auth-card--hidden');
  });

  // ── Password visibility toggle ─────────
  function setupToggle(btn, inputId) {
    if (!btn) return;
    btn.addEventListener('click', () => {
      const input = document.getElementById(inputId);
      if (!input) return;
      const isPass = input.type === 'password';
      input.type = isPass ? 'text' : 'password';
      btn.querySelector('.eye-open').style.display  = isPass ? 'none' : 'block';
      btn.querySelector('.eye-closed').style.display = isPass ? 'block' : 'none';
    });
  }

  setupToggle(toggleSignin, 'signinPass');
  setupToggle(toggleSignup, 'signupPass');

  // ── Toast helper ───────────────────────
  function showToast(message, type = 'success') {
    if (!toastWrap) return;
    const colors = {
      success: { bg: '#10b981', icon: '✓' },
      error:   { bg: '#ef4444', icon: '✗' },
      info:    { bg: '#3b82f6', icon: 'ℹ' }
    };
    const c = colors[type] || colors.success;
    const toast = document.createElement('div');
    toast.style.cssText = `
      display:flex;align-items:center;gap:10px;padding:12px 20px;
      background:${c.bg};color:#fff;border-radius:10px;font-size:14px;
      font-family:'DM Sans',sans-serif;font-weight:500;
      box-shadow:0 4px 12px rgba(0,0,0,0.15);
      animation:slideIn 0.3s ease;min-width:280px;
    `;
    toast.innerHTML = `<span style="font-size:18px;">${c.icon}</span> ${message}`;
    toastWrap.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(20px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  function clearFieldError(inputId) {
    const wrap = document.getElementById(inputId)?.closest('.field__wrap');
    if (wrap) wrap.classList.remove('error');
    const errorEl = document.getElementById(inputId + 'Error');
    if (errorEl) {
      errorEl.textContent = '';
      errorEl.classList.remove('visible');
    }
  }

  function setFieldError(inputId, message) {
    const wrap = document.getElementById(inputId)?.closest('.field__wrap');
    if (wrap) wrap.classList.add('error');
    const errorEl = document.getElementById(inputId + 'Error');
    if (errorEl) {
      errorEl.textContent = message;
      errorEl.classList.add('visible');
    }
  }

  function clearSigninErrors() {
    clearFieldError('signinId');
    clearFieldError('signinPass');
  }

  ['signinId', 'signinPass'].forEach(fieldId => {
    const input = document.getElementById(fieldId);
    if (input) {
      input.addEventListener('input', () => clearFieldError(fieldId));
    }
  });

  signinForm?.addEventListener('submit', e => {
    e.preventDefault();
    clearSigninErrors();
    const adminId  = document.getElementById('signinId')?.value.trim();
    const password = document.getElementById('signinPass')?.value;

    if (!adminId) {
      setFieldError('signinId', 'Email is required.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(adminId)) {
      setFieldError('signinId', 'Enter a valid email address.');
      return;
    }

    if (!password) {
      setFieldError('signinPass', 'Password is required.');
      return;
    }

    if (password.length < 6) {
      setFieldError('signinPass', 'Password must be at least 6 characters.');
      return;
    }

    // Check stored accounts first
    const accounts = JSON.parse(localStorage.getItem('nexuspay_admin_accounts') || '[]');
    const found = accounts.find(a => (a.email === adminId || a.adminId === adminId) && a.password === password);

    // Default admin credentials
    const isDefault = (adminId === 'admin@nexuspay.com' && password === 'admin123');

    if (found || isDefault) {
      const btn = document.getElementById('signinBtn');
      btn.textContent = 'Signing In...';
      btn.disabled = true;
      btn.style.opacity = '0.7';

      // Store session
      localStorage.setItem('nexuspay_admin_session', JSON.stringify({
        adminId: adminId,
        name: found ? found.name : 'Admin User',
        email: found ? found.email : 'admin@nexuspay.com',
        loggedIn: true,
        timestamp: Date.now()
      }));

      showToast('Sign in successful! Redirecting...', 'success');

      setTimeout(() => {
        window.location.href = '../dashboard/index.html';
      }, 1200);
    } else {
      showToast('Invalid Admin ID or Password.', 'error');
      // Shake the form
      signinForm.style.animation = 'shake 0.4s ease';
      setTimeout(() => signinForm.style.animation = '', 400);
    }
  });

  // ── SIGN UP ────────────────────────────
  signupForm?.addEventListener('submit', e => {
    e.preventDefault();
    const name     = document.getElementById('signupName')?.value.trim();
    const email    = document.getElementById('signupEmail')?.value.trim();
    const password = document.getElementById('signupPass')?.value;
    const confirm  = document.getElementById('signupConfirm')?.value;

    if (!name || !email || !password || !confirm) {
      showToast('Please fill in all fields.', 'error');
      return;
    }

    if (password.length < 6) {
      showToast('Password must be at least 6 characters.', 'error');
      return;
    }

    if (password !== confirm) {
      showToast('Passwords do not match.', 'error');
      return;
    }

    // Generate admin ID
    const adminId = String(Math.floor(100000000 + Math.random() * 900000000));

    // Store account
    const accounts = JSON.parse(localStorage.getItem('nexuspay_admin_accounts') || '[]');
    accounts.push({ adminId, name, email, password });
    localStorage.setItem('nexuspay_admin_accounts', JSON.stringify(accounts));

    const btn = document.getElementById('signupBtn');
    btn.textContent = 'Creating Account...';
    btn.disabled = true;
    btn.style.opacity = '0.7';

    showToast(`Account created! Your Admin ID: ${adminId}`, 'success');

    setTimeout(() => {
      // Pre-fill the sign-in form
      document.getElementById('signinId').value = adminId;
      document.getElementById('signinPass').value = '';
      signupForm.classList.add('auth-card--hidden');
      signinForm.classList.remove('auth-card--hidden');
      btn.textContent = 'Create Account';
      btn.disabled = false;
      btn.style.opacity = '1';
      signupForm.reset();
    }, 2000);
  });
});
